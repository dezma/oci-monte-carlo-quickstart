# Threat model and security review prompts

## Assets

- Simulation inputs, model parameters, and any regulated portfolio data.
- Partial and aggregate simulation results.
- OCI infrastructure state, image manifests, and Kubernetes configuration.
- The ability to run or alter simulations.

## Primary threats and controls

| Threat | Design control | Customer decision required |
|---|---|---|
| Public control-plane or workload exposure | Private endpoint and subnets; no public service in the chart; private operator reached only through time-limited Bastion sessions | Set the narrow Bastion client CIDR and review session use. |
| Operator credential theft | Operator uses an instance principal; no user API key, private key, or OCIR token is injected by Terraform | Review the explicit operator Kubernetes access mode: `iam_admin` is scoped to the one cluster; `namespace_rbac` requires a one-time least-privilege RoleBinding. Review bootstrap object access, OS patching, and auth-token rotation. |
| Credential theft from a pod | Object Storage mode uses OKE Workload Identity with no OCI config/API key in the image; FSS mode does not mount a workload identity token | Review the selected result-delivery design and the separately rotated OCIR pull secret. |
| OCIR pull access confused with operator access | The Bastion-reached operator uses an instance principal for OCI control-plane access, while Kubernetes uses a namespace-scoped `ocir-pull` secret for private image pulls | Keep the pull credential out of Terraform, source control, and shell history; rotate it before expiry. |
| Operator privilege escalation in Kubernetes | `iam_admin` is constrained to the created cluster for smooth onboarding; `namespace_rbac` binds the operator dynamic group to only the named namespace resources used by the quickstart | The FSS baseline requires `iam_admin` to install its cluster-scoped PV. With Object Storage and `namespace_rbac`, have a cluster administrator apply the generated RBAC manifest. |
| Workload privilege escalation in Kubernetes | Restricted Pod Security, non-root user, no privilege escalation/capabilities, read-only root | Enforce compatible admission policy across the cluster. |
| Lateral pod movement | Namespace isolation and default-deny ingress/controlled egress policy | Validate CNI policy enforcement and additional namespace rules. |
| Image tampering | Digest-only deployment and build provenance/SBOM generation | Configure OCI Registry vulnerability scanning and signed-image admission policy. |
| Result tampering or mix-up | Input hash, run ID, partition metadata, conditional write-once objects or atomic write-once FSS files, scoped identity/export controls | Set bucket or filesystem retention, encryption, backup, and result-retention policy. |
| Shared-filesystem lateral access | Dedicated mount-target subnet, FSS NSGs, export options limited to worker and operator subnets, non-root workload UID | Treat worker clients sharing the squashed identity as one trust group. Review client CIDRs, export options, node access and backups; application-level write-once publication is not a retention lock. |
| Unbounded cloud cost | Explicit node/pod resource limits, job deadline, TTL, pre-apply plan | Set budgets, quotas, and a project-specific maximum parallelism. |

## Production review checklist

- Is the compartment inside a Security Zone or monitored by Cloud Guard?
- Are Object Storage bucket retention and customer-managed encryption required?
- In Object Storage mode, does the IAM policy remain limited to the one result bucket/prefix, with only `OBJECT_CREATE` available to the runtime?
- In FSS mode, are mount-target NSGs and export options limited to the required worker and operator networks, with backups and retention defined?
- Has OCI Registry image signing and vulnerability scanning been enforced before deployment?
- Does the production cluster enforce Pod Security Admission, RBAC, NetworkPolicy, and audit logging?
- Is the Bastion client CIDR narrow, are sessions time-limited, and is operator dynamic-group access reviewed separately from the workload policy?
